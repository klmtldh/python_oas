# encoding: utf-8

"""
lxml custom element classes for DrawingML line-related XML elements.
"""

from __future__ import absolute_import
